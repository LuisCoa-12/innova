package Modelo;

public class CarroRepuestos {
    private int idRepuesto, cantidad;

    public CarroRepuestos(int idRepuesto, int cantidad) {
        this.idRepuesto = idRepuesto;
        this.cantidad = cantidad;
    }

    public int getIdRepuesto() {
        return idRepuesto;
    }

    public void setIdRepuesto(int idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
}
