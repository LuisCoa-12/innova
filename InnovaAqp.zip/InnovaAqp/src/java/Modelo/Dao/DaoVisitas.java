package Modelo.Dao;

import Modelo.CarroRepuestos;
import Modelo.Repuesto;
import Modelo.Usuario;
import Modelo.Visita;
import Modelo.VisitaProgramada;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DaoVisitas extends Conexion{
    public List<Visita> consultarPendientes(String tipo) {
        List<Visita> lst = new ArrayList<>();
        Connection cnx = obtenerConexion();
        String sql = "SELECT * FROM cita WHERE pendiente = 1 AND tipo_atencion LIKE ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, "%"+tipo+"%");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {                
                Visita visita = new Visita();
                visita.setIdCita(rs.getInt(1));
                visita.setTipoEq(rs.getString(3));
                visita.setMarcaEq(rs.getString(4));
                visita.setModeloEq(rs.getString(5));
                visita.setFechEq(rs.getInt(6));
                visita.setProblemaEq(rs.getString(7));
                visita.setIdPersona(rs.getInt(8));
                visita.setIdTiposervicio(rs.getInt(9));
                lst.add(visita);
            }
        } catch (Exception e) {
            throw new RuntimeException();
        }
        return lst;
    }
    public void programarVisita(VisitaProgramada vp){
        Connection cnx = obtenerConexion();
        String sql = "INSERT INTO visita(fecha, hora_visita, costo_visita, id_cita, id_tecnico) "
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, vp.getFecha());
            stm.setString(2, vp.getHora());
            stm.setDouble(3, vp.getCosto());
            stm.setInt(4, vp.getIdCita());
            stm.setInt(5, vp.getIdTecnico());
            stm.execute();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                System.out.println("Error" + e);
                throw new RuntimeException(e);
            }
        }
    }
    public void actualizarCita(int idCita){
        Connection cnx = obtenerConexion();
        String sql = "UPDATE cita SET pendiente = 0 WHERE id_cita = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setInt(1, idCita);
            stm.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                System.out.println("Error" + e);
                throw new RuntimeException(e);
            }
        }
    }
    public void ordenRepuestosUsados(List<CarroRepuestos> carroRepuestos, String fecha, String hora, String descripcion, int idCita) {
        Connection cnx = obtenerConexion();
        double total = 0.0;
        String uuid = (UUID.randomUUID().toString());
        for (CarroRepuestos carro : carroRepuestos) {
            DaoRepuesto dao = new DaoRepuesto();
            Repuesto rep = dao.buscarXid(carro.getIdRepuesto());
            total += rep.getCosto()* carro.getCantidad();
        }
        String sql = "INSERT INTO hoja_servicio(fecha, descripcion_hoja_servicio, hora, montoServicio, id_cita, ref) "
                + "VALUES (?,?,?,?,?,?)";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, fecha);
            stm.setString(2, descripcion);
            stm.setString(3, hora);
            stm.setDouble(4, total);
            stm.setInt(5, idCita);
            stm.setString(6, uuid);
            stm.execute();
            int idCompra = recuperarIDhojaServicio(uuid);
            for (CarroRepuestos carro : carroRepuestos) {
                DaoRepuesto dao = new DaoRepuesto();
                Repuesto rep = dao.buscarXid(carro.getIdRepuesto());
                sql = "INSERT INTO servicio_repuestos(cantidad, precio, id_hoja_servicios, id_repuesto) "
                        + "VALUES (?,?,?,?)";
                PreparedStatement stm2 = cnx.prepareStatement(sql);
                stm2.setInt(1, carro.getCantidad());
                stm2.setDouble(2, rep.getCosto());
                stm2.setInt(3, idCompra);
                stm2.setInt(4, carro.getIdRepuesto());
                stm2.execute();
            }
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                System.out.println("Error" + e);
                throw new RuntimeException(e);
            }
        }
    }
    public int recuperarIDhojaServicio(String ref) {
        Connection cnx = obtenerConexion();
        int id = 0;
        String sql = "SELECT id_hoja_servicio FROM hoja_servicio WHERE ref = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, ref);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception e) {
            throw new RuntimeException();
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return id;
    }
    
    ////////OBTENER DATOS//////////
    public Usuario obtenerPersona(int idPersona){
        Connection cnx = obtenerConexion();
        Usuario us = new Usuario();
        String sql = "SELECT * FROM persona WHERE id_persona = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setInt(1, idPersona);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                us.setNombre(rs.getString(2));
                us.setApellidos(rs.getString(3));
                us.setDni(rs.getInt(4));
                us.setTelefono(rs.getInt(5));
                us.setDireccion(rs.getString(6));
                us.setIdDistrito(rs.getInt(15));
            }
        } catch (Exception e) {
            throw new RuntimeException();
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return us;
    }
    public String obtenerNombreServicio(int idServicio){
        Connection cnx = obtenerConexion();
        String nombreServicio = "";
        String sql = "SELECT nombre_tipo_servicio FROM tipo_servicio WHERE id_tipo_servicio = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setInt(1, idServicio);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                nombreServicio = rs.getString(1);
            }
        } catch (Exception e) {
            throw new RuntimeException();
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return nombreServicio;
    }
    public List<String> obtenerCorreoXcita(int idCita) {
        Connection cnx = obtenerConexion();
        List<String> datos = new ArrayList<>();
        String sql = "SELECT correo, nombre_persona, apellidos FROM persona INNER JOIN cita ON persona.id_persona = cita.id_persona "
                + "WHERE cita.id_cita = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setInt(1, idCita);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                String correo = rs.getString(1);
                String nombres = rs.getString(2);
                String apellidos = rs.getString(3);
                datos.add(correo);
                datos.add(nombres);
                datos.add(apellidos);
            }
        } catch (Exception e) {
            throw new RuntimeException();
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return datos;
    }
}
