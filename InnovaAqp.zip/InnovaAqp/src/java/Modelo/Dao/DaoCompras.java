package Modelo.Dao;

import Modelo.Accesorio;
import Modelo.Carrito;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class DaoCompras extends Conexion {

    public void generarOrdenCompra(List<Carrito> carroCompras) {
        Connection cnx = obtenerConexion();
        LocalDate fecha = LocalDate.now();
        double total = 0.0;
        String uuid = (UUID.randomUUID().toString());
        for (Carrito carro : carroCompras) {
            DaoAccesorios dao = new DaoAccesorios();
            Accesorio ac = dao.buscarXid(carro.getIdAccesorio());
            total += ac.getPrecio() * carro.getCantidad();
        }
        int idUsuario = carroCompras.get(0).getIdUsuario();
        double costoEnvio = 10;
        total += costoEnvio;
        String sql = "INSERT INTO compra(fech_compra,total, id_persona, ref) VALUES (?,?,?,?)";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, fecha + "");
            stm.setDouble(2, total);
            stm.setInt(3, idUsuario);
            stm.setString(4, uuid);
            stm.execute();
            int idCompra = recuperarIDcompra(uuid);
            for (Carrito carro : carroCompras) {
                DaoAccesorios dao = new DaoAccesorios();
                Accesorio ac = dao.buscarXid(carro.getIdAccesorio());
                sql = "INSERT INTO compra_producto(cantidad, precio, id_compra, id_producto) VALUES (?,?,?,?)";
                PreparedStatement stm2 = cnx.prepareStatement(sql);
                stm2.setInt(1, carro.getCantidad());
                stm2.setDouble(2, ac.getPrecio());
                stm2.setInt(3, idCompra);
                stm2.setInt(4, carro.getIdAccesorio());
                stm2.execute();
            }
        } catch (SQLException e) {
            System.out.println(e);
            throw new RuntimeException(e);
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                System.out.println("Error" + e);
                throw new RuntimeException(e);
            }
        }
    }
    public int recuperarIDcompra(String ref) {
        Connection cnx = obtenerConexion();
        int id = 0;
        String sql = "SELECT id_compra FROM compra WHERE ref = ?";
        try {
            PreparedStatement stm = cnx.prepareStatement(sql);
            stm.setString(1, ref);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception e) {
            throw new RuntimeException();
        } finally {
            try {
                cnx.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return id;
    }
}
