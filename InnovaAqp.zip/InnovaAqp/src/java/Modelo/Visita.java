package Modelo;

public class Visita {
    private int idCita, fechEq, idPersona, idTiposervicio;
    private String tipoEq, marcaEq, modeloEq, problemaEq;

    public int getIdCita() {
        return idCita;
    }

    public void setIdCita(int idCita) {
        this.idCita = idCita;
    }

    public int getFechEq() {
        return fechEq;
    }

    public void setFechEq(int fechEq) {
        this.fechEq = fechEq;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public int getIdTiposervicio() {
        return idTiposervicio;
    }

    public void setIdTiposervicio(int idTiposervicio) {
        this.idTiposervicio = idTiposervicio;
    }

    public String getTipoEq() {
        return tipoEq;
    }

    public void setTipoEq(String tipoEq) {
        this.tipoEq = tipoEq;
    }

    public String getMarcaEq() {
        return marcaEq;
    }

    public void setMarcaEq(String marcaEq) {
        this.marcaEq = marcaEq;
    }

    public String getModeloEq() {
        return modeloEq;
    }

    public void setModeloEq(String modeloEq) {
        this.modeloEq = modeloEq;
    }

    public String getProblemaEq() {
        return problemaEq;
    }

    public void setProblemaEq(String problemaEq) {
        this.problemaEq = problemaEq;
    }
    
    
}
