package Controlador.Repuestos;

import Modelo.Dao.DaoRepuesto;
import Modelo.Repuesto;
import Modelo.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "BuscarRepuesto", urlPatterns = {"/BuscarRepuesto"})
public class BuscarRepuesto extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        String cadenaBusqueda = request.getParameter("buscar");
        DaoRepuesto dao = new DaoRepuesto();
        Usuario us = (Usuario)sesion.getAttribute("user");
        List<Repuesto> lst = dao.busquedaReXNombre(cadenaBusqueda);
        request.getSession().setAttribute("cargarListas", lst);
        switch (us.getIdRol()) {
            case 1:
                response.sendRedirect("vistas/administrador/repuestos/listarRepuestos.jsp");
                break;
            case 2:
                response.sendRedirect("vistas/tecnico/agregarRepuestos.jsp");
                break;
            default:
                response.sendRedirect("index.jsp");
                break;
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }
}
