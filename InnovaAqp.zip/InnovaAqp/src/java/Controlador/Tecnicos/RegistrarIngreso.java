package Controlador.Tecnicos;

import Modelo.Dao.DaoEquipo;
import Modelo.Dao.DaoUsuario;
import Modelo.Equipo;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "RegistrarIngreso", urlPatterns = {"/RegistrarIngreso"})
public class RegistrarIngreso extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        DaoUsuario dao = new DaoUsuario();
        String correo = request.getParameter("correo");
        int idCliente = dao.obtenerIdXcorreo(correo);
        if (idCliente > 0) {
            String tipo = request.getParameter("tipo");
            String marca = request.getParameter("marca");
            String modelo = request.getParameter("modelo");
            String problema = request.getParameter("problema");
            int fechFab = Integer.parseInt(request.getParameter("fech-fabricacion"));
            int idServicio = Integer.parseInt(request.getParameter("servicio"));
            Equipo cel = new Equipo(tipo, marca, modelo, problema, fechFab, idCliente, idServicio);
            DaoEquipo daoEquipo = new DaoEquipo();
            daoEquipo.registrarEquipoTaller(cel);
            response.sendRedirect(request.getContextPath() + "/vistas/tecnico/index-tecnico.jsp");
        } else {
            sesion.setAttribute("mensaje", "El cliente no esta registrado");
            response.sendRedirect(request.getContextPath() + "/vistas/tecnico/formularioIngreso.jsp");
        }
    }
}
