package Controlador.Visitas;

import Modelo.CarroRepuestos;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "RemoverRepuesto", urlPatterns = {"/RemoverRepuesto"})
public class RemoverRepuesto extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        List<CarroRepuestos> carroRepuestos = (ArrayList<CarroRepuestos>) sesion.getAttribute("carroRepuestos");
        int idAccesorio = Integer.parseInt(request.getParameter("idre"));
        if (carroRepuestos != null) {
            for (CarroRepuestos carro : carroRepuestos) {
                if (carro.getIdRepuesto()== idAccesorio) {
                    carroRepuestos.remove(carro);
                    break;
                }
            }
        }
        sesion.setAttribute("carroRepuestos", carroRepuestos);
        response.sendRedirect("vistas/tecnico/hojaServicio.jsp");
    }
}
