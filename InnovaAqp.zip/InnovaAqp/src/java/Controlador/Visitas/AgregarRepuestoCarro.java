package Controlador.Visitas;

import Modelo.CarroRepuestos;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AgregarRepuestoCarro", urlPatterns = {"/AgregarRepuestoCarro"})
public class AgregarRepuestoCarro extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        if (sesion.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            sesion.setAttribute("mensaje", "Primero debe iniciar sesion");
        } else {
            int cantidad = Integer.parseInt(request.getParameter("cantidad"));
            int idAccesorio = Integer.parseInt(request.getParameter("reId"));
            List<CarroRepuestos> carroRepuestos;
            if (sesion.getAttribute("carroRepuestos") == null) {
                carroRepuestos = new ArrayList<>();
                request.getSession().setAttribute("carroRepuestos", carroRepuestos);
            } else {
                carroRepuestos = (ArrayList<CarroRepuestos>) sesion.getAttribute("carroRepuestos");
            }
            boolean estaEnCarro = false;
            if (carroRepuestos.size() > 0) {
                for (CarroRepuestos carro : carroRepuestos) {
                    if (idAccesorio == carro.getIdRepuesto()) {
                        if (cantidad + carro.getCantidad() > 0) {
                            carro.setCantidad(carro.getCantidad() + cantidad);
                            estaEnCarro = true;
                        } else {
                            carro.setCantidad(1);
                            estaEnCarro = true;
                        }
                        break;
                    }
                }
            }
            if (!estaEnCarro && cantidad > 0) {
                carroRepuestos.add(new CarroRepuestos(idAccesorio, cantidad));
            }
            sesion.setAttribute("carroRepuestos", carroRepuestos);
            response.sendRedirect("vistas/tecnico/hojaServicio.jsp");
        }
    }
}
