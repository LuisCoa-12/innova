package Controlador.Visitas;

import Modelo.CarroRepuestos;
import Modelo.Dao.DaoVisitas;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "RegistrarHojaServicio", urlPatterns = {"/RegistrarHojaServicio"})
public class RegistrarHojaServicio extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesion = request.getSession();
        int idVisita = Integer.parseInt(request.getParameter("visitaPendiente"));
        if(idVisita > 0){
            String fecha = request.getParameter("fecha");
            String hora = request.getParameter("hora");
            String descServicio = request.getParameter("descripcionServicio");
            double monto = Double.parseDouble(request.getParameter("total"));
            List<CarroRepuestos> carroRepuestos = (ArrayList<CarroRepuestos>)sesion.getAttribute("carroRepuestos");
            DaoVisitas dao = new DaoVisitas();
            dao.ordenRepuestosUsados(carroRepuestos, fecha, hora, descServicio, idVisita);
            dao.actualizarCita(idVisita);
            response.sendRedirect("vistas/tecnico/index-tecnico.jsp");
        } else {
            response.sendRedirect("vistas/tecnico/index-tecnico.jsp");
        }
    }
}
