package Controlador.Visitas;

import Modelo.CarroRepuestos;
import Modelo.Dao.DaoVisitas;
import Modelo.Visita;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "VisitaPendienteTaller", urlPatterns = {"/VisitaPendienteTaller"})
public class VisitaPendienteTaller extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DaoVisitas dao = new DaoVisitas();
        List<Visita> lst = dao.consultarPendientes("");
        List<CarroRepuestos> lstRepuestos = new ArrayList<>();
        request.getSession().setAttribute("visitasPendientesTaller", lst);
        request.getSession().setAttribute("carroRepuestos", lstRepuestos);
        request.getRequestDispatcher("vistas/tecnico/hojaServicio.jsp").forward(request, response);
    }
}
